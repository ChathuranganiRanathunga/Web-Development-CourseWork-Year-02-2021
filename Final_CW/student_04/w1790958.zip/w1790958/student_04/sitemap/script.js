//site map linking all pages
document.getElementById("home").addEventListener("click", () => {
    document.location.href = "../../student_02/html_files/student_02_main.html";
});
document.getElementById("products").addEventListener("click", () => {
    document.location.href = "../../student_01/products.html";
});
document.getElementById("quiz").addEventListener("click", () => {
    document.location.href = "../../Student_03/html_files/quiz.html";
});
document.getElementById("gallery").addEventListener("click", () => {
    document.location.href = "../gallery/index.html";
});
document.getElementById("feedback").addEventListener("click", () => {
    document.location.href = "../../student_02/html_files/feedback.html";
});
document.getElementById("team").addEventListener("click", () => {
    document.location.href = "../../Student_03/html_files/student_details.html";
});